// src/ShapeType.ts
export enum ShapeType {
    Circle = 'CIRCLE',
    Rectangle = 'RECTANGLE'
  }